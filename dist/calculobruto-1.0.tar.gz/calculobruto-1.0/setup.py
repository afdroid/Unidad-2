from setuptools import setup

setup(
    name='calculobruto',
    version='1.0',
    description='Calculo de cantidades brutas',
    author='Alfredo Moreno Corona',
    author_email='moreno.corona.alfredo@gmail.com',
    url='www.utng.edu.mx',
    py_modules=['calculobruto'],
)